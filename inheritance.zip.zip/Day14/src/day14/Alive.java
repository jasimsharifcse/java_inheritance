/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package day14;

/**
 *
 * @author Jasim
 */
public class Alive {
    public boolean life =true;
    public void live()
    {
     System.out.println("They Live");
    }
    
    
}
