/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package day14;


public class Task2 {
    public static void main(String[] args) {
         Alive ob= new Alive();
         ob.live();
         
         Animal sneak=new Animal();
         sneak.live();
         sneak.move();
         
          Mammal manush =new Mammal();
          manush.live();
          manush.walk();
          manush.move();
          
          Plant kolagach=new Plant();
          kolagach.live();
          kolagach.food();
    }
   
}
