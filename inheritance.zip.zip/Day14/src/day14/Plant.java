/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package day14;

/**
 *
 * @author Jasim
 */
public class Plant extends Alive {
 
    
    public void food()
    {
    System.out.println(" They profuce food");
    }
}
