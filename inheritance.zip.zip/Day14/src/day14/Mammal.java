/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package day14;

/**
 *
 * @author Jasim
 */
public class Mammal extends Animal {
   
    public void  walk()
    {
        // System.out.println(" +The Mammal+ ");
    System.out.println("They can walk");
    }
}
