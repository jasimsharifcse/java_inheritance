/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package day14;

/**
 *
 * @author Jasim
 */
public class task3 {
    public static void main(String[] args) {
        Add_Interface ob =new Add() {
           
        };
        System.out.println(ob.add(12, 03));
    }
}
