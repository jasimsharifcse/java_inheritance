/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package day14;

/**
 *
 * @author Jasim
 */
public interface Add_Interface {
    
    public int add(int a, int b); 
}
